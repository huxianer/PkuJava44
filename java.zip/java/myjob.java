package myJavaJob;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.SequenceInputStream;
import java.util.ArrayList;
import java.util.List;

public class javajob {
	
	public static void main(String argv[]){
        String PathA = "E:\\java\\A.txt";
		String PathB = "E:\\java\\B.txt";
		String PathUnion = "E:\\java\\UnionSet.txt";
		String PathCom = "E:\\java\\ComSet.txt";
		String PathTotal = "E:\\java\\TotalSet.txt";

		  ReadFile(PathA);
			ReadFile(PathB);
		
		//������ذٷֱ�
		List<String> list1 = WriteList(PathA);
		List<String> list2 = WriteList(PathB);
		List<String> list3 = WriteList(PathCom);
		
		int a,b,c;
		a=list1.size();   //System.out.print(a+"   ");
		b=list2.size();   //System.out.print(b+"   ");
		c=list3.size();   //System.out.print(c+"   ");
		
		SelectComSet(PathA,PathB);
			
			SelectTotalSet(PathA,PathB);
			
			SelectUnionSet(PathA,PathB);
		
		
		
				   		
    }
    
	//��ȡA.txt��B.txt����
	public static void ReadFile(String filePath){
        try {
                String encoding="GBK";
                File file=new File(filePath);
               
			    if(file.isFile() && file.exists()){ 
				
                    InputStreamReader read = new InputStreamReader(new FileInputStream(file),encoding);
                    
					BufferedReader bufferedReader = new BufferedReader(read);
                   
				    String lineTxt = null;
                    while((lineTxt = bufferedReader.readLine()) != null){
                        System.out.println(lineTxt);
                    }
					
                    read.close();
				}else{
					System.out.println("�ļ������ڣ�");
				}
        } catch (Exception e) {
            e.printStackTrace();
		}     
    }
	
	//�������ļ��е�����ȫ��д��һ��TotalSet.txt�ļ�����
	public static void SelectTotalSet(String PathA,String PathB){
		try{	
			File totalSet = new File("E:/java/TotalSet.txt");   
		
			FileInputStream fileA = new FileInputStream(PathA);
			FileInputStream fileB = new FileInputStream(PathB);
         
			InputStream fileTotal = new SequenceInputStream(fileA,fileB);    
			InputStreamReader fileRead = new InputStreamReader(fileTotal);         
			FileOutputStream fileOut = new FileOutputStream(totalSet,true);         
			OutputStreamWriter fileWrite = new OutputStreamWriter(fileOut);
         
			int a;
			while((a=fileRead.read())!=-1){
				fileWrite.write((char)a);
			}
		
			System.out.println("TotalSet.txt is ok....");
		
			fileRead.close();
			fileWrite.close();
			
			}catch (Exception e) {
				e.printStackTrace();
			}  	
	}
	

	
	//�����в��ظ������ҳ������UniSet.txt�ļ�����
	public static void SelectUnionSet(String PathA,String PathB){
	
		List<String> list1 = WriteList(PathA);
		List<String> list2 = WriteList(PathB);
		List<String> list3 = new ArrayList<>();
		
		list3.addAll(list1);
		for(String s:list2){
			if(list3.contains(s)){
				continue;
				}else{
					list3.add(s);
					}
		}		
			
		FileWriter Write2 = null;
		String uniPath = "E:\\java\\UniSet.txt";
		try {
			Write2 = new FileWriter(uniPath);
			for(String s:list3)
				Write2.write(s+"    ");
			
			Write2.flush();
		} catch (Exception e) {
				e.printStackTrace();
			}  	
			

	}
	
	//��txt�ļ��е����������list��
	public static List<String> WriteList(String fileName){
		List<String> list = new ArrayList<>();
		String[] tempStr;
		String lineStr;
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new  FileReader(fileName));
			while((lineStr = reader.readLine()) != null){
				tempStr = lineStr.split("[\\s,.;!��������]");
				for(String s:tempStr){
					if(!s.trim().equals("")){
						list.add(s.trim());
					}
				}				
			}
		} catch (Exception e) {
				e.printStackTrace();
				}  
		return list;		
	}
	
	//�������ظ��ĵ����ҳ��������AndSet.txt�ļ�����
	public static void SelectComSet(String PathA,String PathB){
	
		List<String> list1 = WriteList(PathA);
		List<String> list2 = WriteList(PathB);
		List<String> list3 = new ArrayList<>();
		

		for(int i=0;i<list2.size();i++){
			String s=null;
			if(list1.contains(s)){
				list3.add(s);
			}
		}
	
		FileWriter Write1 = null;
		String uniPath = "E:\\java\\ComSet.txt";
		try {
		Write1 = new FileWriter(uniPath);
			for(String s:list3)
				Write1.write(s+"    ");
			
			Write1.flush();
		} catch (Exception e) {
				e.printStackTrace();
			}  
	}	

}
